package dao;

import beans.Address;
import beans.Goods;
import beans.Order;
import beans.User;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import utils.JDBCUtils;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class GoodsDao {
    private JdbcTemplate template=new JdbcTemplate(JDBCUtils.getDataSource());


    /**
     * 接口16：上传我的商品
     * 输入:{userID: 上传用户id,name:商品名，detail：商品描述，count：商品数量，price：商品单价，
     * picurllist（商品图片）:[{picurl:商品图片},…,{}]
     * }
     * @param goods
     * @param picList
     * @return
     */
    public boolean uploadMyGood(Goods goods, List<String> picList){
        //String sql="insert into address(userID,specificaddr, name, phone) values (?, ? ,? ,?)";
        //return template.update(sql,id,specificaddr,name,phone);
        int picListSize = picList.size();
        String firstPicurl = picList.get(0);



        //执行结果
        int step1 = -1;

        try{
            String sql = "insert into " +
                    "goods(goodsName, goodsDetail, goodsPrice, goodsClass,goodsNumber, goodsSeller, goodsPicturePath) " +
                    "values (?, ?, ?, ?, ?, ?,?)";
            step1 = template.update(sql, goods.getGoodsName(), goods.getGoodsDetail(), goods.getGoodsPrice(),goods.getGoodsClass(),
                                            goods.getGoodsNumber(), goods.getGoodsSeller(), picList.get(0));
        }catch(Exception e){
            System.out.println("上传商品时候错误");
        }
        if(picListSize > 1)
        {
            int goodsID = -1;
            //先找回goodsID
            try{
                String sql ="select goods.goodsID " +
                        "from goods " +
                        "where goods.goodsName = ? and goods.goodsSeller = ?";
                goodsID = template.queryForObject(sql, int.class, goods.getGoodsName(), goods.getGoodsSeller());
                //插入picture表
                String sqlPic = "insert into " +
                        "picture(goodsID, picurl) " +
                        "values (?, ?)";
                for(int i = 1; i < picListSize; i++)
                {
                    try{
                        template.update(sqlPic, goodsID, picList.get(i));
                    }catch (Exception e){
                        System.out.println("上传商品时，插入额外的第" + i + "张图片失败");
                    }
                }
            }catch (Exception e){
                System.out.println("找回刚刚创建的Goods的id失败");
            }
        }
        if(step1 == -1)//只有1张图片的时候
            return false;
        else
            return true;
    }

    /**
     * 接口17
     * 查看我上传的商品列表
     * @param UserID
     * @return
     */
    public List<Goods> getGoodsListByUserID(int UserID){
        List<Goods> goods = null;
        try {
            String sql = "select * from goods where goods.goodsSeller= ?";
            goods = template.query(sql, new BeanPropertyRowMapper<>(Goods.class), UserID);
        } catch (Exception e) {
            System.out.println("接口17获取商品列表的sql失效");
        }
        return goods;
    }

    /**
     * 接口18
     * 删除我的商品
     * @param goodsID
     * @return
     */
    public boolean deleteGoodByGoodID(int goodsID){
        //String sql = "delete from picture where goodsID = ?";
        //template.update(sql, goodsID);
        String sql="delete from goods where goodsID = ?";
        int result = template.update(sql,goodsID);
        if(result == 1)
            return true;
        else
            return false;
    }

    /**
     * 接口19
     * 编辑修改我的商品
     * 输入: {id：商品id(无需修改)，name:商品名，detail：商品详细，count：总量，price：单价}
     * @param
     * @return
     */
    public boolean changeGoodByNewInfo(int goodsID, String goodsName, String goodsDetail, String goodsClass, BigDecimal goodsPrice,int goodsNumber){
        //System.out.println(newGood.getGoodsID());
        int result = -1;
        try{
            String sql="update goods " +
                    "set goodsName = ? , goodsDetail = ?, goodsNumber = ?, goodsPrice = ? ,goodsClass=?" +
                    "where goodsID = ?";
            result = template.update(sql,
                    goodsName, goodsDetail,goodsNumber
                    ,goodsPrice,goodsClass,goodsID
                    );
        }catch(Exception e) {
            System.out.println("修改商品失败");
        }
        System.out.println("执行结果："+result);
        if(result == 1)
            return true;
        else
            return false;
    }

    /**
     * 田国庆
     * 第二波接口
     * 2.1-(1) part2
     * 获取网站数据
     */
    public int getGoodsNum()
    {
        int goodsNum = -1;
        List<Goods> numArray = null;
        try{
            String sql = "select goods.goodsNumber from goods";
            numArray = template.query(sql, new BeanPropertyRowMapper<>(Goods.class));
            int size = numArray.size();
            goodsNum = 0;
            for(int i = 0; i < size; i++)
            {
                goodsNum += numArray.get(i).getGoodsNumber();
            }
            System.out.println("求得商品总数目是：" + goodsNum);
        }catch (Exception e) {
            System.out.println("获取商品数目列表失败");
        }
        return goodsNum;
    }




    /**
     * 田国庆
     * 第二波接口
     * 2.3-(1)
     * 获取所有用户的所有商品
     */
    public List<Goods> getGoodsList() {
        List<Goods> goods = null;
        try {
            String sql = "select * from goods";
            goods = template.query(sql, new BeanPropertyRowMapper<>(Goods.class));
        } catch (Exception e) {
            System.out.println("接口17获取商品列表的sql失效");
        }
        return goods;
    }

    public List<Goods> getGoodsListByUserID(int UserID,int page ,int limit){
        List<Goods> goods = null;
        try {
            String sql = "select * from goods where goods.goodsSeller= ? order by goodsID limit ?,?";
            goods = template.query(sql, new BeanPropertyRowMapper<>(Goods.class), UserID,limit * (page - 1),limit);
        } catch (Exception e) {
            System.out.println("接口17获取商品列表的sql失效");
        }
        return goods;
    }

    /**
     * 田国庆 第三波接口
     * 根据商品id获取商品的详细
     */
    public Goods getGoodDetailByID(int goodId){
        Goods detailGood = null;
        List<String> wholePicPath = new ArrayList<>();
        try {
            String sql = "select * from goods where goods.goodsID= ?";
            detailGood = template.queryForObject(sql, new BeanPropertyRowMapper<>(Goods.class), goodId);
            //System.out.println(detailGood+"!!!");
        } catch (Exception e) {
            System.out.println("获取商品详情第一部分失败！");
        }

        try{
            wholePicPath.add(detailGood.getGoodsPicturePath());
            //找出picture表
            String sql = "select picurl from picture where goodsID = ?";
            List<String> extraPicList = new ArrayList<>();
            extraPicList = template.queryForList(sql, String.class, goodId);
            //System.out.println(extraPicList+"!!!!");
            int extraSize = extraPicList.size();
            for(int i = 0; i < extraSize; i++){
                wholePicPath.add(extraPicList.get(i));
            }
            detailGood.setWholePicPath(wholePicPath);
        } catch (Exception e){
            System.out.println("获取商品详情中图片列表失败！");
        }
        return detailGood;
    }

    /**
     * 田国庆 第三波接口
     * 根据商品类型特征获取商品的列表
     */
    public List<Goods> getGoodListByClass(String keyword, List<String> type,
                                          int order, BigDecimal maxPrice, BigDecimal minPrice){
        List<Goods> goods = null;
        //order 1价格升序，0价格降序，-1默认排序
        String orderStr = "";
        if(order == 1)
        {
            orderStr = " order by goodsPrice asc";
        }else if(order == 0)
        {
            orderStr = " order by goodsPrice desc";
        }else if(order == -1)
        {
            orderStr = "";
        }
        String keywordStr = "";
        if(keyword != "")
            keywordStr = " and (goodsName like '%" + keyword + "%' or goodsDetail like '%" + keyword + "%')";
        try {
            String sql = "select * from goods where goodsPrice >= ? and goodsPrice <= ?" + keywordStr + orderStr;
            goods = template.query(sql, new BeanPropertyRowMapper<>(Goods.class), minPrice, maxPrice);
        } catch (Exception e) {
            System.out.println("获取指定特征商品，获取所有的商品失败");
        }
        System.out.println(goods + "第一次查询");
        //type的筛选
        List<Goods> newGoods = new ArrayList<>();
        if(type != null && type.size() > 0)
        {
            System.out.println("进入if开始排除类别");
            int len = goods.size();
            for(int i = 0; i < len; i++){
                //去除此商品
                boolean ifContain = type.contains(goods.get(i).getGoodsClass());
                System.out.println("第"+i+"次循环"+ifContain);
                if(ifContain){
                    newGoods.add(goods.get(i));
                }
            }
        }
        else{
            newGoods = goods;
        }
        //System.out.println(newGoods + "第二次查询");
        //筛选后加入图片列表
        int finalLen = newGoods.size();
        for(int i = 0; i < finalLen; i++){
            try{
                List<String> wholePicPath = new ArrayList<>();
                wholePicPath.add(goods.get(i).getGoodsPicturePath());
                //找出picture表
                String sql = "select picurl from picture where goodsID = ?";
                List<String> extraPicList = template.queryForList(sql, String.class, newGoods.get(i).getGoodsID());
                int extraSize = extraPicList.size();
                for(int j = 0; j < extraSize; j++){
                    wholePicPath.add(extraPicList.get(j));
                }
                newGoods.get(i).setWholePicPath(wholePicPath);
            } catch (Exception e){
                System.out.println("第" + i + "次获取商品详情中图片列表失败！");
            }
        }
        return newGoods;
    }


    /**
     * 田国庆 管理员的搜索功能
     * 根据关键字搜索商品
     */
    public List<Goods> getGoodListByKeyword(String keyword){
        List<Goods> goods = null;
        try{
//            keywordStr = " and (goodsName like '%" + keyword + "%' or goodsDetail like '%" + keyword + "%')";
            String sql = "select * from goods where goodsName like '%" + keyword + "%' or goodsDetail like '%" + keyword + "%'";
            goods = template.query(sql, new BeanPropertyRowMapper<>(Goods.class));
        }catch(Exception e){
            System.out.println("根据关键字搜索商品抛出异常");
        }
        return goods;
    }
}
