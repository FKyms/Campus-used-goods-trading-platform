package dao;

import beans.Address;
import beans.Carts;
import beans.Goods;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import utils.JDBCUtils;

import java.sql.SQLException;
import java.util.List;

public class CartDao {
    private JdbcTemplate template=new JdbcTemplate(JDBCUtils.getDataSource());
    public List<Goods> GetCartListByUID(int userID) {
        List<Goods> goods=null;
        try {
            String sql="SELECT t2.goodsID, t2.goodsName ,t2.goodsDetail ,t2.goodsPicturePath, " +
                    "t2.goodsPrice ,t1.count FROM carts t1, goods t2 WHERE t1.goodsID = t2.goodsID and t1.userID = ?";
            goods = template.query(sql, new BeanPropertyRowMapper<>(Goods.class), userID);
        } catch (Exception e) {

        }
        return goods;
    }

    public int addGoodsToCarts(int userID, int goodsID, int count) {
        int nums=0;
        Carts cart = null;

        try {
            String sql_select="SELECT  *" +
                    " FROM carts  WHERE  userID = ? AND goodsID = ?";
            cart = template.queryForObject(sql_select, new BeanPropertyRowMapper<>(Carts.class),userID,goodsID);
            if(cart!=null)
            {
                count += cart.getCount();
                String sql = "update carts set count=? where goodsID=? and userID=?";
                nums=template.update(sql,count,goodsID,userID);
                return nums;
            }
            else
            {
                String sql="insert into carts(userID, goodsID, count) values (?, ?, ?)";
                nums=template.update(sql,userID,goodsID,count);
            }

        } catch (Exception e) {
            e.printStackTrace();


        }
        try{
            String sql="insert into carts(userID, goodsID, count) values (?, ?, ?)";
            nums=template.update(sql,userID,goodsID,count);
        }catch (Exception e1)
        {

        }
        return nums;

    }

    public int deleteGoodsFromCart(int userid,int goodsid)
    {
        int nums=0;
        try {
            String sql="delete from  carts where userID=? and  goodsID=?";
            nums=template.update(sql,userid,goodsid);
        } catch (Exception e) {

        }
        return nums;

    }
}
