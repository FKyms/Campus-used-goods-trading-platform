package dao;

import beans.*;
import com.google.gson.Gson;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import utils.DateTimeUtils;
import utils.JDBCUtils;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class OrderDao {
    private JdbcTemplate template=new JdbcTemplate(JDBCUtils.getDataSource());

    /**
     * 第三次被修改 接口12
     * 获取用户订单列表(根据用户id)
     * {id：订单id，name：收货人，phone:联系电话，addr:地址，price:总价，state:状态（1已签收,0已发货,-1等待发货） }
     * @param userID
     * @return
     */
    public List<Order> getOrderListByUserID(int userID){
        List<Order> orders = null;
        try{
            //执行的sql语句
            String sql = "SELECT t1.orderID, t2.name ,t2.phone ,t2.specificaddr, t1.orderPrice, t3.orderDateTime, t1.orderStatus " +
                    "FROM orders t1, address t2, ordersGroup t3 " +
                    "WHERE t1.orderGID = t3.orderGID and t3.addrID = t2.addressID and t3.userID = t2.userID and t3.userID = ?  ";
            orders = template.query(sql, new BeanPropertyRowMapper<>(Order.class), userID);
        }catch (Exception e){
            System.out.println("异常!!!");
        }
        return orders;
    }

    /**
     * 第三次被修改 接口13：根据订单id获取订单详细
     * 在接口12的基础上加入一个goodsList，由于goods需要给多个dao类服务，其必须保存最多的数据，到时候需要进行筛选使用
     * @param orderID
     * @return
     */
    public OrderDetail getOrderDetailByOrderID(int orderID)
    {
//        Order orderDetail1 = null;
//        List<Goods> goods = null;
        Order info = null;
        OrderDetail good = null;
        try{
            //执行的sql语句 先写入订单的除商品列表的信息 只有1条记录
            String sql = "SELECT t1.orderID, t2.name ,t2.phone ,t2.specificaddr, t1.orderPrice ,t3.orderDateTime, t1.orderStatus " +
                    "FROM orders t1, address t2, ordersGroup t3 " +
                    "WHERE t1.orderGID = t3.orderGID and t3.addrID = t2.addressID and t3.userID = t2.userID and t1.orderID = ?";
            info = template.queryForObject(sql, new BeanPropertyRowMapper<>(Order.class), orderID);
        }catch(Exception e){
            System.out.println("总函数获取订单学习（非商品）异常1");
        }
        /**
         *     private int goodsID;
         *     private String goodsName;
         *     private String goodsDetail;
         *     private int count;
         *     private int orderStatus;
         */
        try{
            //找出专属的一个商品
            String sql = "SELECT t2.goodsID, t2.goodsName, t2.goodsDetail, t1.count " +
                    "FROM orders t1, goods t2 " +
                    "WHERE t1.orderID = ? and t1.goodsID = t2.goodsID ";
            good = template.queryForObject(sql, new BeanPropertyRowMapper<>(OrderDetail.class), orderID);

        }catch(Exception e){
            System.out.println("总函数获取订单详情（单商品部分）异常2");
        }
        good.setSpecificOrder(info);
        return good;
    }

    /**
     * 第三次被修改 接口15
     * 下单生成订单列表（每种商品生成一个订单）
     */
    /**
     * 输入
     * {
     *  orderlist:
     *  [
     *    {id:商品id，count:购买数量}，
     *     …
     *  ],
     *  orderaddr（收货人信息）：
     *  {
     *  id：收货地址id，specificaddr:具体住址，name:收货人名，phone: 收货人电话号码
     *  }
     */
    public List<Integer> createOrder(List<Goods> orderlist, Address address){
        List<Integer> orderIDList = new ArrayList<>();

        /**
         * 根据商品列表计算订单金额 初始订单状态为 待发货
         */
        /**
         * 方案
         * 获取商品总金额 -》插入订单组 -》查出订单组id 根据时间等 -》插入多个订单
         * 1. 获取商品总金额
         */
        //4个步骤得到的结果
        int step2 = -1;
        int step3 = -1;
        int step4 = -1;

        BigDecimal soloPrice = new BigDecimal("0");
        List<BigDecimal> priceItemList = new ArrayList<>();
        BigDecimal totalPrice = new BigDecimal("0");
        int indexIDSql1;
        int countSql1;
        String sql1;
        for(int i = 0;i < orderlist.size();++i)
        {
            try{
                indexIDSql1 = orderlist.get(i).getGoodsID();
                countSql1 = orderlist.get(i).getCount();//购买个数
                sql1 = "SELECT t1.goodsPrice " +
                        "FROM goods t1 " +
                        "WHERE t1.goodsID = ?";
                //BigDecimal price;
                soloPrice = template.queryForObject(sql1, BigDecimal.class, indexIDSql1);
                System.out.println(soloPrice+"商品单价");
                //把商品数目转换为BigDecimal
                BigDecimal countBig = new BigDecimal(countSql1);
                priceItemList.add(soloPrice.multiply(countBig));
                System.out.println(priceItemList.get(i)+"单商品总价");
                totalPrice = totalPrice.add(priceItemList.get(i));
                System.out.println("接口15第一步执行结果总金额：" + totalPrice);
            }catch(Exception e){
                System.out.println("接口15计算订单中一种商品的总金额错误！（5件A）第"+ i +"次循环");
            }
        }
        /**
         * 2. 插入订单组
         *    首先 计算userID 计算DateTime
         */
        int userID = -1;
        try{
            String sql ="select address.userID from address where address.addressID = ?";
            userID = template.queryForObject(sql, int.class, address.getAddressID());
            System.out.println("接口15计算userID结果：" + userID);
        }catch (Exception e)
        {
            System.out.println("接口15 根据address对象找userID 错误");
        }

        Date now = new Date();
        System.out.println("下单的初始时间：");
        System.out.println(now.toString());
        String orderDateTime = DateTimeUtils.DateToMySQLDateTimeString(now);
        System.out.println("下单的转换后时间：");
        System.out.println(orderDateTime);

        try{
            //-1等待发货
            String sql="insert into ordersGroup(userID, orderDateTime, orderGPrice, addrID) values (?, ? ,? ,?)";
            step2 = template.update(sql, userID, orderDateTime, totalPrice, address.getAddressID());
            System.out.println("接口15第二步(创建订单组)执行结果：" + step2);
        }catch(Exception e){
            System.out.println("接口15插入订单第二步(创建订单组)错误");
        }
        /**
         * 3. 查出订单组合id 根据时间等
         */
        int orderGID = -1;
        try{
            String sql = "select orderGID " +
                    "from ordersGroup " +
                    "where userID = ? and orderDateTime = ? and orderGPrice = ? and addrID = ?";
            orderGID = template.queryForObject(sql, Integer.class, userID, orderDateTime, totalPrice, address.getAddressID());
            step3 = orderGID;
            System.out.println("接口15第三步执行结果：" + step2);
        }catch (Exception e){
            System.out.println("接口15查出订单组id（根据时间等）错误");
        }
        System.out.println("查出的orderGID:"+ orderGID);
        /**
         * 4. 插入多个订单 状态首先为-2
         * List<Goods> orderlist
         */
        int goodsIDSql4;
        int countSql4;
        BigDecimal priceSql4;
        String sql4;
        int goodsNumberSql4;//存放原来的库存量 以执行减少下单库存
        for(int i = 0;i < orderlist.size();++i)
        {
            goodsNumberSql4 = 0;//以防止查询失败时候产生不利的影响
            goodsIDSql4 = orderlist.get(i).getGoodsID();
            countSql4 = orderlist.get(i).getCount();
            priceSql4 = priceItemList.get(i);
            try{
                sql4 = "insert into orders(orderGID, goodsID, count, orderStatus, orderPrice) values(?, ?, ?, -2, ?)";
                step4 += template.update(sql4, orderGID, goodsIDSql4, countSql4, priceSql4);
                System.out.println("接口15第四步第" + i + "次循环执行结果：" + step4);
            }catch (Exception e){
                System.out.println("接口15第四布插入多个订单项 错误，第"+ i +"次循环");
            }
            //在goods表查出商品数目
            try{
                sql4 = "select goodsNumber from goods where goodsID = ?";
                goodsNumberSql4 = template.queryForObject(sql4, Integer.class, goodsIDSql4);
                System.out.println("接口15第四步第" + i + "次循环查询当前商品库存：" + goodsNumberSql4 );
            }catch (Exception e){
                System.out.println("接口15第四步第" + i + "次循环查询当前商品库存失败");
            }
            //在goods表中执行更新库存
            try{
                sql4 = "update goods set goodsNumber = ? where goodsID = ?";
                int resOfDel = template.update(sql4, goodsNumberSql4 - countSql4, goodsIDSql4);
                System.out.println("接口15第四步第" + i + "次循环更新库存结果（期待1）：" + resOfDel);
            }catch (Exception e){
                System.out.println("接口15第四步第" + i + "次循环更新库存结果抛出异常");
            }
        }

        //判断插入效果
//        if(userID == -1 || step2 == -1 || step3 == -1 || step4 == -1)
//        {
//           return false;
//        }
//        return true;
        //orderGID
        try{
            String sql5 = "select orderID from orders where orderGID = ?";
            orderIDList = template.queryForList(sql5, Integer.class, orderGID);
        }catch(Exception e){
            System.out.println("创建订单后获取订单号列表失败！");
        }
        return orderIDList;
    }

    /**
     * 第三次被修改 第二次
     * 田国庆
     * 第二波接口
     * 2.3-(3)
     * 获取所有订单数据（所有的用户）
     */
    public List<Order> getOrderList()
    {
        List<Order> orders = null;
        try{
//            //执行的sql语句
//            String sql = "SELECT t1.orderID, t2.name ,t2.phone ,t2.specificaddr, t1.orderPrice ,t1.orderStatus " +
//                    "FROM orders t1, address t2 " +
//                    "WHERE t1.addrID = t2.addressID and t1.userID = t2.userID";
//            orders = template.query(sql, new BeanPropertyRowMapper<>(Order.class));
            //执行的sql语句
            String sql = "SELECT t1.orderID, t2.name ,t2.phone ,t2.specificaddr, t1.orderPrice ,t3.orderDateTime, t1.orderStatus " +
                    "FROM orders t1, address t2, ordersGroup t3 " +
                    "WHERE t1.orderGID = t3.orderGID and t3.addrID = t2.addressID and t3.userID = t2.userID";
            orders = template.query(sql, new BeanPropertyRowMapper<>(Order.class));
        }catch (Exception e){

        }
        return orders;
    }

    /**
     * 田国庆
     * 第二波接口
     * 2.3-(4)
     * 删除某一订单
     */
    public boolean deleteOrderById(int orderID){
        String sql="delete from orders where orderID = ?";
        int result = template.update(sql, orderID);
        if(result == 1)
            return true;
        else
            return false;
    }

    /**
     * 田国庆 第三波接口
     * 付款 输入的内容是一个orderID（int）数组
     * -2 变 -1
     */
    public boolean payOrders(List<Integer> orderIDList){
        //在orders表中执行更新
        String sql = "update orders set orderStatus = -1 where orderID = ?";
        int resOfUpdate = -1;
        int lenOfList = orderIDList.size();
        for(int i = 0; i < lenOfList; i++){
            try{
                resOfUpdate += template.update(sql, orderIDList.get(i));
                System.out.println("接口支付订单状态第" + i + "次循环后：" + resOfUpdate);
            }catch (Exception e){
                System.out.println("接口支付订单状态第" + i + "次循环更新库存结果抛出异常");
            }
        }
        return !(resOfUpdate == -1);
    }

    /**
     * 田国庆 第三波接口
     * 签收 输入的内容是一个orderID
     * 0 变 1
     */
    public boolean signForOrder(int orderID){
        //在orders表中执行更新
        String sql = "update orders set orderStatus = 1 where orderID = ?";
        int result = -1;
        try{
            result = template.update(sql, orderID);
            System.out.println("接口签收订单状态为：" + result);
        }catch (Exception e){
            System.out.println("接口签收订单失败！");
        }
        return !(result == -1);
    }



    /**
     * 田国庆 第三波接口
     * 签收 输入的内容是一个orderID
     * 0 变 1
     */
    public boolean sendGoods(int orderID){
        //在orders表中执行更新
        String sql = "update orders set orderStatus = 0 where orderID = ?";
        int result = -1;
        try{
            result = template.update(sql, orderID);
            System.out.println("接口签收订单状态为：" + result);
        }catch (Exception e){
            System.out.println("接口签收订单失败！");
        }
        return !(result == -1);
    }

    /**
     * 田国庆 第三波接口
     * 根据店主的id获取订单列表
     */
    public List<Order> getOrderListByOwnerID(int ownerID,int limit,int page){
        List<Order> orders = null;
        try{
            //执行的sql语句
            String sql = "SELECT t1.orderID, t2.name ,t2.phone ,t2.specificaddr, t1.orderPrice, t3.orderDateTime, t1.orderStatus " +
                    "FROM orders t1, address t2, ordersGroup t3, goods t4 " +
                    "WHERE t1.orderGID = t3.orderGID and t3.addrID = t2.addressID and t3.userID = t2.userID " +
                    "and t1.goodsID = t4.goodsID and t4.goodsSeller = ? limit ?,?";
            orders = template.query(sql, new BeanPropertyRowMapper<>(Order.class), ownerID,limit * (page - 1),limit);
        }catch (Exception e){

        }
        return orders;
    }

    /**
     * 田国庆 管理员的搜索功能
     * 根据关键字搜索订单
     */
    public List<OrderDetail> getOrderListByKeyword(String keyword){
        List<Order> orders = null;
        List<OrderDetail> orderDetails = new ArrayList<>();
        try{
            String sql = "select t1.orderID, t4.name, t4.phone," +
                    " t4.specificaddr, t1.orderPrice, t3.orderDateTime, t1.orderStatus " +
                    "from orders t1, goods t2, ordersGroup t3, address t4 " +
                    "where (t2.goodsName like '%" + keyword + "%' or t2.goodsDetail like '%" + keyword + "%') " +
                    "and t1.goodsID = t2.goodsID and t1.orderGID = t3.orderGID " +
                    "and t3.addrID = t4.addressID";
            orders = template.query(sql, new BeanPropertyRowMapper<>(Order.class));
        }catch(Exception e){
            System.out.println("根据关键字搜索订单part1抛出异常");
        }
        if(orders != null)
        {
            int len = orders.size();
            int orderID = -1;
            String sqlDetail = "select t2.goodsID, t2.goodsName, t2.goodsDetail, t1.count " +
                    "from orders t1, goods t2 " +
                    "where t1.orderID = ? and t1.goodsID = t2.goodsID";
            for(int i = 0; i < len; i++){
                orderID = orders.get(i).getOrderID();
                //System.out.println(orderID + "第" +i +"次");
                OrderDetail oD = null;
                try{
                    oD = template.queryForObject(sqlDetail, new BeanPropertyRowMapper<>(OrderDetail.class), orderID);
                }catch(Exception e){
                    System.out.println("第"+i+"次循环找出detail失败（关键字订单）");
                }
                if(oD != null){
                    oD.setSpecificOrder(orders.get(i));
                    orderDetails.add(oD);
                }
            }
        }
        return orderDetails;
    }
}