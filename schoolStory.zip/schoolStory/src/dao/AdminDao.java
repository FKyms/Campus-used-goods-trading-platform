package dao;

import beans.Admin;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import utils.JDBCUtils;

public class AdminDao {
    private JdbcTemplate template=new JdbcTemplate(JDBCUtils.getDataSource());

    public Admin loginAdmin(String username, String pwd) {
        Admin admin=null;
        try {
            String sql="select * from admin where adminName = ? and adminPW = ?";
            admin = template.queryForObject(sql, new BeanPropertyRowMapper<>(Admin.class), username, pwd);
        } catch (Exception e) {
        }

        return admin;
    }

    public boolean changeAdminMsg(int id, String name, String phone, String email) {
        int num=0;
        try {
            String sql="update admin set adminName = ? , adminPhone = ? , adminEmail = ? where adminID = ? ";
            num = template.update(sql, name, phone,email,id);
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (num==1){
            return true;
        }
        return false;
    }

    public Admin testPassword(String oldpwd, int id) {
        Admin admin=null;
        try {
            String sql="select * from admin where adminID = ? and adminPW = ?";
            admin = template.queryForObject(sql, new BeanPropertyRowMapper<>(Admin.class), id,oldpwd);
        } catch (Exception e) {

        }

        return admin;
    }

    public boolean changePassword(int id, String newpwd) {
        String sql="update admin set adminPW= ? where adminID= ?";
        int num = template.update(sql, newpwd,id);
        if (num==0){
            return false;
        }
        return true;
    }
}
