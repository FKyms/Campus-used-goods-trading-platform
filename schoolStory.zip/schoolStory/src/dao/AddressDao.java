package dao;

import beans.Address;
import beans.User;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import utils.JDBCUtils;

import java.util.ArrayList;
import java.util.List;

public class AddressDao {
    private JdbcTemplate template=new JdbcTemplate(JDBCUtils.getDataSource());

    /**
     * 根据用户id查询所有地址
     * @param id
     * @return
     */
    public List<Address> findAddressListById(int id,int limit,int page){
        List<Address> addresses=null;
        try {
            String sql="select * from address  where address.userID = ? order by addressID limit ?,?";
            addresses = template.query(sql, new BeanPropertyRowMapper<>(Address.class), id,limit * (page - 1),limit);
        } catch (Exception e) {

        }
        return addresses;
    }

    public List<Address> findAddressListById(int id){
        List<Address> addresses=null;
        try {
            String sql="select * from address  where address.userID = ? ";
            addresses = template.query(sql, new BeanPropertyRowMapper<>(Address.class), id);
        } catch (Exception e) {

        }
        return addresses;
    }

    /**
     * 根据地址id删除地址
     * @param id
     * @return
     * @return
     */
    public int deleteAddressById(int id){
        String sql="delete from address  where addressID = ?  ";
        return template.update(sql,id);
    }

    public int changeAddress(int id, String specificaddr, String name, String phone) {
        String sql="update address set specificaddr = ? , name = ?, phone = ? where addressID = ?";
        return template.update(sql,specificaddr,name,phone,id);
    }

    public int newAddress(int id, String specificaddr, String name, String phone) {
        String sql="insert into address(userID,specificaddr, name, phone) values (?, ? ,? ,?)";
        return template.update(sql,id,specificaddr,name,phone);
    }
}
