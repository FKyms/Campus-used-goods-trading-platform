package dao;

import beans.Address;
import beans.User;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import utils.JDBCUtils;

import java.util.ArrayList;
import java.util.List;


public class UserDao {
    private JdbcTemplate template=new JdbcTemplate(JDBCUtils.getDataSource());

    /**
     * 根据id查找单个用户及其收获地址列表
     * @param id
     * @return
     */
    public User findUserById(int id){
        User user=null;
        try {
            String sql="select user.userID,user.userName,user.userEmail from user  where userID = ?";
            user = template.queryForObject(sql, new BeanPropertyRowMapper<>(User.class), id);
        } catch (Exception e) {

        }
        return user;
    }

    /**
     * 根据id验证旧密码是否正确
     * @param id
     * @return
     */
    public User testPassword(String oldpwd,int id){
        User user=null;
        try {
            String sql="select * from user where userID = ? and userPW = ?";
            user = template.queryForObject(sql, new BeanPropertyRowMapper<>(User.class), id,oldpwd);
        } catch (Exception e) {

        }

        return user;
    }



    /**
     * 根据ID修改用户名
     * @param id
     * @param name
     * @return
     */
    public boolean changeUsername(int id, String name) {
        String sql="update user set userName=? where userID= ?";
        int num = template.update(sql, name, id);
        if (num==0){
            return false;
        }
        return true;

    }



    public boolean changePassword(int id,String newpwd) {
        String sql="update user set userPW=? where userID= ?";
        int num = template.update(sql, newpwd,id);
        if (num==0){
            return false;
        }
        return true;
    }

    public boolean changeEmail(int id, String email) {
        String sql="update user set userEmail = ? where userID= ?";
        int num = template.update(sql, email,id);
        if (num==0){
            return false;
        }
        return true;
    }

    public boolean registerUser(String username, String pwd, String email) {
        String sql="insert into user(userName , userPW , userEmail) values(? , ? , ?)";
        int num = 0;
        try {
            num = template.update(sql, username,pwd,email);
        } catch (DataAccessException e) {

        }
        if (num==0){
            return false;
        }
        return true;
    }

    public User loginUser(String username, String pwd) {
        User user=null;
        try {
            String sql="select * from user where userEmail = ? and userPW = ?";
            user = template.queryForObject(sql, new BeanPropertyRowMapper<>(User.class), username, pwd);
        } catch (Exception e) {

        }

        return user;
    }

    /**
     * 此dao中两者都有代码 下面是田国庆的
     */
    /**
     * 田国庆
     * 第二波接口
     * 2.1-(1) part1
     * 获取网站数据
     */
    public int getUsersNum()
    {
        int usersNum = -1;
        try{
            String sql = "select count(*) as count from user";
            usersNum = template.queryForObject(sql, int.class);
            System.out.println("求得用户总数目是：" + usersNum);
        }catch (Exception e)
        {
            System.out.println("查询用户总数目失败");
        }
        return usersNum;
    }

    /**
     * 田国庆
     * 第二波接口
     * 2.2-(1)
     * 获取所有用户信息
     */
    public List<User> getUsersList()
    {
        List<User> users = null;
        try {
            String sql="select * from user";
            users = template.query(sql, new BeanPropertyRowMapper<>(User.class));
        } catch (Exception e) {
            System.out.println("查询所有的用户数据失败");
        }
        return users;
    }

    /**
     * 田国庆
     * 第二波接口
     * 2.2-(2)
     * 删除选中用户
     */
    public int deleteUserById(int userID)
    {
        String sql="delete from user where userID = ?";
        return template.update(sql, userID);
    }


    /**
     * 田国庆 管理员的搜索功能
     * 根据关键字搜索用户
     */
    public List<User> getUserListByKeyword(String keyword){
        List<User> users= null;
        try{
//            keywordStr = " and (goodsName like '%" + keyword + "%' or goodsDetail like '%" + keyword + "%')";
            String sql = "select * from user where userName like '%" + keyword + "%' ";
            users = template.query(sql, new BeanPropertyRowMapper<>(User.class));
        }catch(Exception e){
            System.out.println("根据关键字搜索用户抛出异常");
        }
        return users;
    }




}
