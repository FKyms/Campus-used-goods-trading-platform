package service;

import beans.Admin;
import dao.AdminDao;

public class AdminService {
    private AdminDao dao=new AdminDao();

    public Admin loginAdmin(String username, String pwd) {
        return  dao.loginAdmin(username,pwd);
    }

    public boolean changeAdminMsg(int id, String name, String phone, String email) {
        return dao.changeAdminMsg(id,name,phone,email);
    }

    public boolean testPassword(String oldpwd, int id) {
        Admin admin = dao.testPassword(oldpwd, id);
        if (admin!=null){
            return true;//存在
        }
        return false;
    }

    public boolean changePassword(int id, String newpwd) {
        return dao.changePassword(id,newpwd);
    }
}
