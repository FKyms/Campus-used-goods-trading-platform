package service;

import beans.Address;
import beans.Goods;
import beans.Order;
import beans.OrderDetail;
import dao.OrderDao;

import java.util.List;

public class OrderService {
    OrderDao orderDao = new OrderDao();

    //接口12的service
    public List<Order> getOrderListByUserID(int userID)
    {
        return orderDao.getOrderListByUserID(userID);
    }

    //接口13的service
    public OrderDetail getOrderDetailByOrderID(int orderID)
    {
        return orderDao.getOrderDetailByOrderID(orderID);
    }

    //接口15的service
    public List<Integer> CreateOrder(List<Goods> orderlist, Address address)
    {
        return orderDao.createOrder(orderlist, address);
    }
    /**
     * 田国庆
     * 第二波接口
     * 2.3-(3)
     * 获取所有订单数据（所有的用户）
     */
    public List<Order> getOrderList()
    {
        return orderDao.getOrderList();
    }

    /**
     * 田国庆
     * 第二波接口
     * 2.3-(4)
     * 删除某一订单
     */
    public boolean deleteOrderById(int orderID){
        return orderDao.deleteOrderById(orderID);
    }

    /**
     * 田国庆 第三波接口
     * 付款 输入的内容是一个orderID（int）数组
     * -2 变 -1
     */
    public boolean payOrders(List<Integer> orderIDList){
        return orderDao.payOrders(orderIDList);
    }

    /**
     * 田国庆 第三波接口
     * 签收 输入的内容是一个orderID
     * 0 变 1
     */
    public boolean signForOrder(int orderID){
        return orderDao.signForOrder(orderID);
    }

    /**
     * 田国庆 第三波接口
     * 签收 输入的内容是一个orderID
     * -1 变 0
     */

    public boolean SendGoods(int orderID){
        return orderDao.sendGoods(orderID);
    }

    /**
     * 田国庆 第三波接口
     * 根据店主的id获取订单列表
     */
    public List<Order> getOrderListByOwnerID(int ownerID,int limit,int page){
        return orderDao.getOrderListByOwnerID(ownerID,limit,page);
    }

    /**
     * 田国庆 管理员的搜索功能
     * 根据关键字搜索订单
     */
    public List<OrderDetail> getOrderListByKeyword(String keyword){
        return orderDao.getOrderListByKeyword(keyword);
    }
}
