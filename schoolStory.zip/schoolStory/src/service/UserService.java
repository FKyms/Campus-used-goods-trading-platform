package service;

import beans.Address;
import beans.User;
import dao.AddressDao;
import dao.UserDao;

import java.util.List;
//单纯用于测试
public class UserService {
    UserDao userDao = new UserDao();
    AddressDao addressDao=new AddressDao();

    /**
     * 根据id修改用户姓名
     * @param id
     * @param name
     * @return
     */
    public boolean changeUsername(int id, String name) {
        return userDao.changeUsername(id,name);
    }

    public User findUserById(int id){
        User user=userDao.findUserById(id);
        List<Address> addressListById = addressDao.findAddressListById(id);
        if (user!=null){
            user.setAddrList(addressListById);
        }
        return user;
    }

    /**
     * 根据密码 id查找用户是否存在
     * @param oldpwd
     * @param id
     * @return
     */
    public boolean testPassword(String oldpwd,int id){
        User user = userDao.testPassword(oldpwd, id);
        if (user!=null){
            return true;//存在
        }
        return false;
    }

    public boolean changePassword(int id, String newpwd) {
        return userDao.changePassword(id,newpwd);
    }

    public boolean changeEmail(int id, String email) {
        return userDao.changeEmail(id,email);
    }

    public boolean registerUser(String username, String pwd, String email) {
        return userDao.registerUser(username,pwd,email);
    }

    public User loginUser(String username, String pwd) {
        return userDao.loginUser(username,pwd);
    }

    /**
     * 此service中两者都有代码 下面是田国庆的
     */
    /**
     * 田国庆
     * 第二波接口
     * 2.1-(1)
     */
    public int getUsersNum(){
        return userDao.getUsersNum();
    }

    /**
     * 田国庆
     * 第二波接口
     * 2.2-(1)
     * 获取所有用户信息
     */
    public List<User> getUsersList(){
        return userDao.getUsersList();
    }

    /**
     * 田国庆
     * 第二波接口
     * 2.2-(2)
     * 删除选中用户
     */
    public int deleteUserById(int userID)
    {
        return userDao.deleteUserById(userID);
    }



    /**
     * 田国庆 管理员的搜索功能
     * 根据关键字搜索用户
     */
    public List<User> getUserListByKeyword(String keyword){
        return userDao.getUserListByKeyword(keyword);
    }
}
