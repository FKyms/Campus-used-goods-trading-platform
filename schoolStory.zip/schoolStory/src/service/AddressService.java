package service;

import beans.Address;
import beans.User;
import dao.AddressDao;
import dao.UserDao;

import java.util.List;

public class AddressService {
    AddressDao addressDao=new AddressDao();
    UserDao userDao=new UserDao();
    public boolean deleteAddress(int id){
        int i = addressDao.deleteAddressById(id);
        if (i==1){
            return true;
        }
        return false;
    }

    public boolean ChangeAddress(int id, String specificaddr, String name, String phone) {
        int i=addressDao.changeAddress(id,specificaddr,name,phone);
        if (i==1){
            return true;
        }
        return false;
    }

    public boolean newAddress(int userID, String specificaddr, String name, String phone) {
        //因为userID是外键，若对应主键不存在则Insert语句会出错，故先判断userID是否存在
        User userById = userDao.findUserById(userID);
        if (userById!=null){
            int i=addressDao.newAddress(userID,specificaddr,name,phone);
            if (i==1){
                return true;
            }
        }
        return false;
    }

    /**
     * 接口14的service 田国庆
     * @param userID
     * @return
     */
    public List<Address> findAddressListById(int userID,int limit ,int page)
    {
        return addressDao.findAddressListById(userID,limit,page);
    }

    public List<Address> findAddressListById(int userID)
    {
        return addressDao.findAddressListById(userID);
    }
}
