package service;

import beans.Goods;
import dao.CartDao;

import java.util.List;

public class CartService {
    CartDao cartDao=new CartDao();
    public List<Goods> getCartListByUID(int userID){
        return cartDao.GetCartListByUID(userID);
    }

    public boolean addGoodsToCarts(int userID, int goodsID, int count) {
        int nums=cartDao.addGoodsToCarts(userID,goodsID,count);
        if (nums==1){
            return true;
        }
        return false;
    }

    public boolean deleteGoodsFromCart(int userid, int goodsid)
    {
        int nums = cartDao.deleteGoodsFromCart( userid,goodsid);
        if(nums==1)
        {
            return true;
        }
        else
            return false;
    }
}
