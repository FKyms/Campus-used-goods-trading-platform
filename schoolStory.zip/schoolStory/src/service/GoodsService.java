package service;

import beans.Goods;
import dao.GoodsDao;

import java.math.BigDecimal;
import java.util.List;

public class GoodsService {
    GoodsDao goodsDao = new GoodsDao();

    //接口16的service 上传我的商品
    public boolean uploadMyGood(Goods goods, List<String> picList){
        return goodsDao.uploadMyGood(goods, picList);
    }

    //接口17的service 获取我上传的商品列表
    public List<Goods> getGoodsListByUserID(int UserID){
        return goodsDao.getGoodsListByUserID(UserID);
    }

    public List<Goods> getGoodsListByUserID(int UserID,int page,int limit){
        return goodsDao.getGoodsListByUserID(UserID,page,limit);
    }

    //接口18的service 删除我的商品（goodsID）
    public boolean deleteGoodByGoodID(int goodsID){
        return goodsDao.deleteGoodByGoodID(goodsID);
    }

    //接口19的service 编辑修改我的商品
    public boolean changeGoodByNewInfo(int goodsID, String goodsName, String goodsDetail, String goodsClass, BigDecimal goodsPrice,int goodsNumber){
        return goodsDao.changeGoodByNewInfo( goodsID, goodsName,  goodsDetail,  goodsClass,  goodsPrice, goodsNumber);
    }

    /**
     * 田国庆
     * 第二波接口
     * 2.1-(1) part2
     */
    public int getGoodsNum()
    {
        return goodsDao.getGoodsNum();
    }

    /**
     * 田国庆
     * 第二波接口
     * 2.3-(1)
     * 获取所有用户的所有商品
     */
    public List<Goods> getGoodsList()
    {
        return goodsDao.getGoodsList();
    }

    /**
     * 田国庆
     * 第三波接口
     * 根据商品id获取商品的详细
     */
    public Goods getGoodDetailByID(int goodId){
        return goodsDao.getGoodDetailByID(goodId);
    }

    /**
     * 田国庆 第三波接口
     * 根据商品类型特征获取商品的列表
     */
    public List<Goods> getGoodListByClass(String keyword, List<String> type,
                                          int order, BigDecimal maxPrice, BigDecimal minPrice){
        return goodsDao.getGoodListByClass(keyword, type, order, maxPrice, minPrice);
    }

    /**
     * 田国庆 管理员的搜索功能
     * 根据关键字搜索商品
     */
    public List<Goods> getGoodListByKeyword(String keyword){
        return goodsDao.getGoodListByKeyword(keyword);
    }

}
