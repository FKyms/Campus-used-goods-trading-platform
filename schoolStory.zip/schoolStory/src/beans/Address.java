package beans;

import java.io.Serializable;

/**
 * 地址实体类，一个用户可以对应多个地址
 */
public class Address implements Serializable {
    private int addressID;
    private int userID;
    private String specificaddr;
    private String name;
    private String phone;

    public int getAddressID() {
        return addressID;
    }

    public void setAddressID(int addressID) {
        this.addressID = addressID;
    }

    public int getUserID() {
        return userID;
    }

    public void setUserID(int userID) {
        this.userID = userID;
    }

    public String getSpecificaddr() {
        return specificaddr;
    }

    public void setSpecificaddr(String specificaddr) {
        this.specificaddr = specificaddr;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    @Override
    public String toString() {
        return "Address{" +
                "addressID=" + addressID +
                ", userID=" + userID +
                ", specificaddr='" + specificaddr + '\'' +
                ", name='" + name + '\'' +
                ", phone='" + phone + '\'' +
                '}';
    }
}
