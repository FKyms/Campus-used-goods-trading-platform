package beans;

/**
 * 记录网站信息
 */
public class WebData {
    private int usersNum;
    private int goodsNum;//所有商品的库存量

    public void setUsersNum(int usersNum)
    {
        this.usersNum = usersNum;
    }

    public int getUsersNum()
    {
        return usersNum;
    }

    public void setGoodsNum(int goodsNum) {
        this.goodsNum = goodsNum;
    }

    public int getGoodsNum() {
        return goodsNum;
    }

    public WebData(int usersNum, int goodsNum)
    {
        this.usersNum = usersNum;
        this.goodsNum = goodsNum;
    }
}
