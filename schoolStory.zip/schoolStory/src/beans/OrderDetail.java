package beans;

import javax.print.DocFlavor;
import java.text.StringCharacterIterator;
import java.util.List;

/**
 *包含订单商品详细信息的实体类
 */
public class OrderDetail {
    private Order specificOrder;
    private int goodsID;
    private String goodsName;
    private String goodsDetail;
    private int count;
//    private int orderStatus;

    public Order getSpecificOrder() {
        return specificOrder;
    }

    public void setSpecificOrder(Order specificOrder) {
        this.specificOrder = specificOrder;
    }

    public int getGoodsID() {
        return goodsID;
    }

    public void setGoodsID(int goodsID) {
        this.goodsID = goodsID;
    }

    public String getGoodsName(){
        return goodsName;
    }

    public void setGoodsName(String goodsName) {
        this.goodsName = goodsName;
    }

    public String getGoodsDetail(){
        return goodsDetail;
    }

    public void setGoodsDetail(String goodsDetail) {
        this.goodsDetail = goodsDetail;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

//    public int getOrderStatus() {
//        return orderStatus;
//    }
//
//    public void setOrderStatus(int orderStatus) {
//        this.orderStatus = orderStatus;
//    }

    @Override
    public String toString() {
        return "OrderDetail{" +
                "id=" + specificOrder.getOrderID() +
                ", name='" + specificOrder.getName() + '\'' +
                ", phone='" + specificOrder.getPhone() + '\'' +
                ", addr='" + specificOrder.getSpecificaddr() + '\'' +
                ", price='" + specificOrder.getOrderPrice() + '\'' +
                ", dateTime='" + specificOrder.getOrderDateTime() + '\'' +
                ", state='" + specificOrder.getOrderStatus() + '\'' +
                ", goodsID=" + goodsID +
                ", goodsName='" + goodsName + '\'' +
                ", goodsDetail='" + goodsDetail + '\'' +
                ", count=" + count +
//                ", orderStatus=" + orderStatus +
                '}';
    }
}
