package beans;

import java.io.Serializable;
import java.util.List;


/**
 * 用户实体类
 */
public class User implements Serializable {

    private int userID;
    private String userName;
    private String userPW;
    private String userPhone;
    private String userEmail;
    private List<Address> addrList;

    public List<Address> getAddrList() {
        return addrList;
    }

    public void setAddrList(List<Address> addrList) {
        this.addrList = addrList;
    }


    public int getUserID() {
        return userID;
    }

    public void setUserID(int userID) {
        this.userID = userID;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserPW() {
        return userPW;
    }

    public void setUserPW(String userPW) {
        this.userPW = userPW;
    }

    public String getUserPhone() {
        return userPhone;
    }

    public void setUserPhone(String userPhone) {
        this.userPhone = userPhone;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }


    @Override
    public String toString() {
        return "User{" +
                "userID=" + userID +
                ", userName='" + userName + '\'' +
                ", userPW='" + userPW + '\'' +
                ", userPhone='" + userPhone + '\'' +
                ", userEmail='" + userEmail + '\'' +
                ", addressList=" + addrList +
                '}';
    }
}

