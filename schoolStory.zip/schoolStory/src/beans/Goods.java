package beans;

import java.math.BigDecimal;
import java.util.List;

/**
 * 商品实体类
 */
public class Goods {
    private int goodsID;
    private String goodsName;
    private String goodsClass;
    private String goodsDetail;
    private BigDecimal goodsPrice;
    private int goodsSeller;
    private int goodsNumber;
    private String goodsPicturePath;
    private int count;//田国庆修改过注释 与goodsNumber（库存量）不同 是购物车或订单中的购买数量
    private List<String> wholePicPath;//田国庆添加
    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public int getGoodsID() {
        return goodsID;
    }


    public void setGoodsID(int goodsID) {
        this.goodsID = goodsID;
    }

    public String getGoodsName() {
        return goodsName;
    }

    public void setGoodsName(String goodsName) {
        this.goodsName = goodsName;
    }

    public String getGoodsClass() {
        return goodsClass;
    }

    public void setGoodsClass(String goodsClass) {
        this.goodsClass = goodsClass;
    }

    public String getGoodsDetail() {
        return goodsDetail;
    }

    public void setGoodsDetail(String goodsDetail) {
        this.goodsDetail = goodsDetail;
    }

    public BigDecimal getGoodsPrice() {
        return goodsPrice;
    }

    public void setGoodsPrice(BigDecimal goodsPrice) {
        this.goodsPrice = goodsPrice;
    }

    public int getGoodsSeller() {
        return goodsSeller;
    }

    public void setGoodsSeller(int goodsSeller) {
        this.goodsSeller = goodsSeller;
    }

    public int getGoodsNumber() {
        return goodsNumber;
    }

    public void setGoodsNumber(int goodsNumber) {
        this.goodsNumber = goodsNumber;
    }

    public String getGoodsPicturePath() {
        return goodsPicturePath;
    }

    public void setGoodsPicturePath(String goodsPicturePath) {
        this.goodsPicturePath = goodsPicturePath;
    }

    public List<String> getWholePicPath() {
        return wholePicPath;
    }

    public void setWholePicPath(List<String> wholePicPath) {
        this.wholePicPath = wholePicPath;
    }

    @Override
    public String toString() {
        return "Goods{" +
                "goodsID=" + goodsID +
                ", goodsName='" + goodsName + '\'' +
                ", goodsClass='" + goodsClass + '\'' +
                ", goodsDetail='" + goodsDetail + '\'' +
                ", goodsPrice=" + goodsPrice +
                ", goodsSeller=" + goodsSeller +
                ", goodsNumber=" + goodsNumber +
                ", goodsPicturePath='" + goodsPicturePath + '\'' +
                ", count=" + count +
                ", picurlist=" + wholePicPath +
                '}';
    }
}