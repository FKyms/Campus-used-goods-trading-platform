package beans;

import java.math.BigDecimal;

/**
 * 订单实体类
 */
public class Order {
    private int orderID;
    private String name;
    private String phone;
    private String specificaddr;
    private BigDecimal orderPrice;
    private String orderDateTime;
    private int orderStatus;// 被修改 -2 --》2

    public int getOrderID() {
        return orderID;
    }

    public void setOrderID(int orderID)
    {
        this.orderID = orderID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone)
    {
        this.phone = phone;
    }

    public String getSpecificaddr() {
        return specificaddr;
    }

    public void setSpecificaddr(String specificaddr)
    {
        this.specificaddr = specificaddr;
    }

    public BigDecimal getOrderPrice() {
        return orderPrice;
    }

    public void setOrderPrice(BigDecimal orderPrice)
    {
        this.orderPrice = orderPrice;
    }

    public String getOrderDateTime() {
        return orderDateTime;
    }

    public void setOrderDateTime(String orderDateTime) {
        this.orderDateTime = orderDateTime;
    }

    public int getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(int orderStatus)
    {
        this.orderStatus = orderStatus;
    }

    @Override
    public String toString() {
        return "Order{" +
                "id=" + orderID +
                ", name='" + name + '\'' +
                ", phone='" + phone + '\'' +
                ", addr='" + specificaddr + '\'' +
                ", price=" + orderPrice +
                ", dateTime='" + orderDateTime + '\'' +
                ", state=" + orderStatus +
                '}';
    }
}