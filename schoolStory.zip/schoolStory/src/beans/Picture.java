package beans;

public class Picture {
    private String picurl;

    public Picture(String picurl)
    {

        this.picurl = picurl;
    }

    public String getPicurl() {
        return picurl;
    }

    public void setPicurl(String picurl) {
        this.picurl = picurl;
    }

    @Override
    public String toString() {
        return "Picture{" +
                "picurl='" + getPicurl() + '\'' +
                '}';
    }
}
