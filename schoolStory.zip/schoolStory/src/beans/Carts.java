package beans;

/**
 * 购物车实体类，多个购物车组成一个用户下的订单
 */
public class Carts {
    private int cartsID;
    private int userID;
    private int goodsID;
    private int count;

    public int getCartsID() {
        return cartsID;
    }

    public void setCartsID(int cartsID) {
        this.cartsID = cartsID;
    }

    public int getUserID() {
        return userID;
    }

    public void setUserID(int userID) {
        this.userID = userID;
    }

    public int getGoodsID() {
        return goodsID;
    }

    public void setGoodsID(int goodsID) {
        this.goodsID = goodsID;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    @Override
    public String toString() {
        return "Carts{" +
                "cartsID=" + cartsID +
                ", userID=" + userID +
                ", goodsID=" + goodsID +
                ", count=" + count +
                '}';
    }
}
