package web.servlet;

import beans.ResultInfo;
import com.fasterxml.jackson.databind.ObjectMapper;
import service.AdminService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * 验证管理员旧密码，更改新密码
 */
@WebServlet("/ChangeAdminPasswordServlet")
public class ChangeAdminPasswordServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        String oldpwd = request.getParameter("oldpwd");
        String newpwd = request.getParameter("newpwd");

        AdminService service=new AdminService();
        ResultInfo info=new ResultInfo();
        boolean flag= service.testPassword(oldpwd, id);
        if (flag){
            //用户存在
            boolean flag1 = service.changePassword(id, newpwd);
            if (flag1){
                //修改成功
                info.setCode(1);
                info.setMsg("修改密码成功");
            }else {
                info.setCode(0);
                info.setMsg("修改密码失败");
            }
        }else {
            info.setCode(0);
            info.setMsg("对应用户不存在或密码不正确");
        }


        ObjectMapper mapper=new ObjectMapper();
        String json = mapper.writeValueAsString(info);
        response.setContentType("application/json;charset=utf-8");
        response.getWriter().write(json); //字符流写回
        System.out.println(json);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}
