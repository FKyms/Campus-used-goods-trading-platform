package web.servlet;

import beans.Address;
import beans.Goods;
import beans.ResultInfo;
import beans.User;
import com.fasterxml.jackson.databind.ObjectMapper;
import service.AddressService;
import service.GoodsService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

/**
 * 接口17
 * 查看我上传的商品列表
 * method: GET
 */
@WebServlet("/GetGoodsListByUIDServlet")
public class GetGoodsListByUIDServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        ResultInfo info = new ResultInfo();
        //使用session获取userID
        HttpSession session = request.getSession();
        User u= (User)session.getAttribute("user");
        int id = u.getUserID();
//        int id =1;
        String pageStr = request.getParameter("page");
        String limitStr = request.getParameter("limit");

        //加载数据表格使用
        GoodsService goodsService = new GoodsService();
        List<Goods> goodsInOrder = goodsService.getGoodsListByUserID(id,Integer.parseInt(pageStr),Integer.parseInt(limitStr));
        if (goodsInOrder!=null){
            info.setCode(0);
            info.setMsg("获取商品列表成功");
            info.setData(goodsInOrder);
            info.setCount(goodsInOrder.size());
        }else {
            info.setCode(1);
            info.setMsg("用户未上传商品");
        }


        //使用service





        /**
         * {"code":1,
         *  "msg":"获取订单列表成功"
         *  "data":
         *  [
         *  {"goodsID":1,"goodsName":"三体","goodsClass":null,"goodsDetail":"玄幻小说",
         * "goodsPrice":4.44,"goodsSeller":0,"goodsNumber":0,"goodsPicturePath":"a.jpg","count":1},
         * ..{}
         * ]
         * }
         * 返回数据格式如上，取其中的即可
         */
        ObjectMapper mapper=new ObjectMapper();
        String json = mapper.writeValueAsString(info);
        response.setContentType("application/json;charset=utf-8");
        response.getWriter().write(json); //字符流写回
        System.out.println("GetGoodsListByUIDServlet:");
        System.out.println(json);
    }
}
