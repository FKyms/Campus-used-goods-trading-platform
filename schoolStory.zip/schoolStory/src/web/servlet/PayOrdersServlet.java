package web.servlet;

import beans.Goods;
import beans.ResultInfo;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import service.GoodsService;
import service.OrderService;
import utils.JsonToStrUtils;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * POST
 * 田国庆 第三波接口
 * 付款，输入int数组（orderID）
 */
@WebServlet("/PayOrdersServlet")
public class PayOrdersServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        /**
         * 输入
         * {
         * orderIDList:[1,2]
         * }
         */

        //工具类
        String JsonStr = JsonToStrUtils.getRequestJsonString(request);
        JsonParser parser = new JsonParser();
        JsonObject jsonObj = parser.parse(JsonStr).getAsJsonObject();
        System.out.println(jsonObj);

        JsonArray list = jsonObj.getAsJsonArray("orderIDList");
        int Len = list.size();
        List<Integer> idList = new ArrayList<>();
        for(int i = 0; i < Len; i++){
            idList.add(list.get(i).getAsInt());
        }

        //使用service
        OrderService service = new OrderService();
        ResultInfo info = new ResultInfo();
        boolean result = service.payOrders(idList);

        if (result){
            info.setCode(1);
            info.setMsg("订单付款成功");
        }else {
            info.setCode(0);
            info.setMsg("订单付款失败");
        }

        ObjectMapper mapper=new ObjectMapper();
        String json = mapper.writeValueAsString(info);
        response.setContentType("application/json;charset=utf-8");
        response.getWriter().write(json); //字符流写回
        System.out.println(json);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}
