package web.servlet;

import beans.Admin;
import beans.ResultInfo;
import com.fasterxml.jackson.databind.ObjectMapper;
import service.AdminService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/LoginAdminServlet")
public class LoginAdminServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String username = request.getParameter("username");
        String pwd = request.getParameter("pwd");

        HttpSession session = request.getSession();
        AdminService service=new AdminService();
        ResultInfo info=new ResultInfo();
        Admin admin =null;
        admin = service.loginAdmin(username,pwd);
        if (admin!=null){
            info.setCode(1);
            info.setMsg("登录成功");
            session.setAttribute("admin",admin);
        }else {
            info.setCode(0);
            info.setMsg("登录失败，用户名或密码错误");
        }


        ObjectMapper mapper=new ObjectMapper();
        String json = mapper.writeValueAsString(info);
        response.setContentType("application/json;charset=utf-8");
        response.getWriter().write(json); //字符流写回
        System.out.println(json);
        //response.sendRedirect("");//要跳转到什么网页自己指定
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}
