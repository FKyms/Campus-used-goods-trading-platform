package web.servlet;

import beans.ResultInfo;
import com.fasterxml.jackson.databind.ObjectMapper;
import service.AddressService;
import service.UserService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * 第二次接口 2.2(2) 田国庆
 * 需要输入userID
 * 删除选中用户（管理员功能）
 * method: GET
 */
@WebServlet("/DeleteUserServlet")
public class DeleteUserServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //根据userID
        int userID = Integer.parseInt(request.getParameter("userID"));
        System.out.println("从request里获取的userID是" + userID);

        UserService service = new UserService();
        ResultInfo info = new ResultInfo();
        int flag = service.deleteUserById(userID);
        if (flag == 1){
            info.setCode(1);
            info.setMsg("删除用户成功");
        }else {
            info.setCode(0);
            info.setMsg("删除用户失败");
        }

        //将结果集对象ResultInfo序列表为json
        ObjectMapper mapper=new ObjectMapper();
        String json = mapper.writeValueAsString(info);
        response.setContentType("application/json;charset=utf-8");
        response.getWriter().write(json); //字符流写回
        System.out.println(json);
    }
}
