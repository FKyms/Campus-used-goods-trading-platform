package web.servlet;

import beans.ResultInfo;
import beans.User;
import com.fasterxml.jackson.databind.ObjectMapper;
import service.UserService;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * 更改用户名
 */
@WebServlet("/ChangeUsernameServlet")
public class ChangeUsernameServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        HttpSession session = request.getSession();
        User u= (User)session.getAttribute("user");//根据id获取数据
        int id = u.getUserID();
//        int id = 1;
        String name = request.getParameter("name");

        UserService service=new UserService();
        ResultInfo info=new ResultInfo();
        boolean flag=service.changeUsername(id,name);
        if (flag){
            info.setCode(1);
            info.setMsg("修改用户名成功");
        }else {
            info.setCode(0);
            info.setMsg("修改用户名失败");
        }

        //将结果集对象ResultInfo序列表为json
        ObjectMapper mapper=new ObjectMapper();
        String json = mapper.writeValueAsString(info);
        response.setContentType("application/json;charset=utf-8");
        response.getWriter().write(json); //字符流写回
        System.out.println(json);

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}
