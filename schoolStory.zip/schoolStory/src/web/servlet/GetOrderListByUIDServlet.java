package web.servlet;

import beans.Order;
import beans.ResultInfo;
import beans.User;
import com.fasterxml.jackson.databind.ObjectMapper;
import service.OrderService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

/**
 * 接口12
 *获取用户订单列表（根据userID）
 * method: GET
 */
@WebServlet("/GetOrderListByUIDServlet")
public class GetOrderListByUIDServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        HttpSession session = request.getSession();
        User u= (User)session.getAttribute("user");
        int id = u.getUserID();
//        int id = 1;
//        int page = Integer.parseInt(request.getParameter("page"));
//        int limit = Integer.parseInt(request.getParameter("limit"));



        OrderService orderService = new OrderService();
        ResultInfo info = new ResultInfo();
        List<Order> orders = orderService.getOrderListByUserID(id);
        if(orders != null)
        {
            info.setCode(1);
            info.setMsg("获取订单列表成功");
            info.setData(orders);
//            info.setCount(orders.size());
        }
        else{
            info.setCode(0);
            info.setMsg("订单列表为空或获取订单列表失败");

        }

        /**
         * {"code":1,
         *  "data":[{"id":1,"name":"小明",
         *            "phone":12364331234,"addr":"江干区",
         *           "price":5.00,"state":1},
         *          {....}
         *          ]
         *   "msg":"获取订单列表成功"
         * }
         */
        ObjectMapper mapper=new ObjectMapper();
        String json = mapper.writeValueAsString(info);
        response.setContentType("application/json;charset=utf-8");
        response.getWriter().write(json); //字符流写回
        System.out.println("GetOrderListByUIDServlet:");
        System.out.println(json);
    }
}
