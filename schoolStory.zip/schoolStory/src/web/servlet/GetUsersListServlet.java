package web.servlet;

import beans.Address;
import beans.ResultInfo;
import beans.User;
import com.fasterxml.jackson.databind.ObjectMapper;
import service.AddressService;
import service.UserService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * 第二次接口 2.2(1) 田国庆
 * 获取所有用户信息
 * method: POST
 */
@WebServlet("/GetUsersListServlet")
public class GetUsersListServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        UserService service = new UserService();
        ResultInfo info = new ResultInfo();
        List<User> users = service.getUsersList();
        if(users != null)
        {
            info.setCode(0);
            info.setMsg("获取用户信息列表成功");
            info.setData(users);
        }else{
            info.setCode(1);
            info.setMsg("获取用户信息列表失败");
        }

        ObjectMapper mapper=new ObjectMapper();
        String json = mapper.writeValueAsString(info);
        response.setContentType("application/json;charset=utf-8");
        response.getWriter().write(json); //字符流写回
        System.out.println(json);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}
