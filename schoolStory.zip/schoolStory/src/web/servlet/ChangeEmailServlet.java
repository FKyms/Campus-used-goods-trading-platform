package web.servlet;

import beans.ResultInfo;
import beans.User;
import com.fasterxml.jackson.databind.ObjectMapper;
import service.UserService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.awt.*;
import java.io.IOException;

/**
 * 修改邮箱
 */
@WebServlet("/ChangeEmailServlet")
public class ChangeEmailServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        User u= (User)session.getAttribute("user");
        int id = u.getUserID();
//        id = 1;//测试
        String code = request.getParameter("code");
        String email = request.getParameter("email");

        ResultInfo info=new ResultInfo();
        String checkCode =(String) session.getAttribute("checkCode");
        UserService userService=new UserService();
        if (checkCode.equals(code)){
            //输入的验证码正确，修改邮箱
            userService.changeEmail(id,email);
            info.setCode(1);
            info.setMsg("验证码正确，修改邮箱成功");
            session.removeAttribute("user");
        }else {
            info.setCode(0);
            info.setMsg("验证码错误，修改邮箱失败");
        }

        //将结果集对象ResultInfo序列表为json
        ObjectMapper mapper=new ObjectMapper();
        String json = mapper.writeValueAsString(info);
        response.setContentType("application/json;charset=utf-8");
        response.getWriter().write(json); //字符流写回
        System.out.println(json);

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}
