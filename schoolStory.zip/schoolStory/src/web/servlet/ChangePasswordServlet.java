package web.servlet;

import beans.ResultInfo;
import beans.User;
import com.fasterxml.jackson.databind.ObjectMapper;
import service.UserService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * 验证旧密码，更改为新密码
 */
@WebServlet("/ChangePasswordServlet")
public class ChangePasswordServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        User u= (User)session.getAttribute("user");//根据id获取数据
        int id = u.getUserID();
//        int id = 1;
        String oldpwd = request.getParameter("oldpwd");
        String newpwd = request.getParameter("newpwd");

        UserService service=new UserService();
        ResultInfo info=new ResultInfo();
        boolean flag= service.testPassword(oldpwd, id);
        if (flag){
            //用户存在
            boolean flag1 = service.changePassword(id, newpwd);
            if (flag1){
                //修改成功
                info.setCode(1);
                info.setMsg("密码修改成功，请重新登录");
                session.removeAttribute("user");
            }else {
                info.setCode(0);
                info.setMsg("修改密码失败");
            }
        }else {
            info.setCode(0);
            info.setMsg("对应用户不存在或密码不正确");
        }

        ObjectMapper mapper=new ObjectMapper();
        String json = mapper.writeValueAsString(info);
        response.setContentType("application/json;charset=utf-8");
        response.getWriter().write(json); //字符流写回
        System.out.println(json);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}
