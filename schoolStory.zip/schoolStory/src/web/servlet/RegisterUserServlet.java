package web.servlet;

import beans.ResultInfo;
import beans.User;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.w3c.dom.CDATASection;
import service.AddressService;
import service.UserService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

/**
 * 注册用户
 */
@WebServlet("/RegisterUserServlet")
public class RegisterUserServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doGet(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String code = request.getParameter("code");
        String pwd = request.getParameter("pwd");
        String email = request.getParameter("email");

        ResultInfo info=new ResultInfo();
        HttpSession session = request.getSession();
        String checkCode =(String)session.getAttribute("checkCode");

        if (checkCode.equalsIgnoreCase(code)){
            UserService service=new UserService();
            boolean flag = service.registerUser(username,pwd,email);
            if (flag){
                info.setCode(1);
                info.setMsg("注册用户成功");
            }else {
                info.setCode(0);
                info.setMsg("注册用户失败，邮箱已存在");
            }
        }else {
            info.setCode(0);
            info.setMsg("验证码错误");
        }



        ObjectMapper mapper=new ObjectMapper();
        String json = mapper.writeValueAsString(info);
        response.setContentType("application/json;charset=utf-8");
        response.getWriter().write(json); //字符流写回
        System.out.println(json);


    }
}
