package web.servlet;

import beans.Goods;
import beans.Order;
import beans.ResultInfo;
import beans.User;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import service.GoodsService;
import service.OrderService;
import utils.JsonToStrUtils;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;

@WebServlet("/GetOrderListByOwnerIDServlet")
public class GetOrderListByOwnerIDServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        /**
         * 田国庆
         * 输入
         * 店主id ownerID
         */

        HttpSession session = request.getSession();
        User u= (User)session.getAttribute("user");
        int id = u.getUserID();
//        int id = 1;
        int page = Integer.parseInt(request.getParameter("page"));
        int limit = Integer.parseInt(request.getParameter("limit"));


        //使用service
        OrderService service = new OrderService();
        ResultInfo info = new ResultInfo();
        List<Order> orders = service.getOrderListByOwnerID(id,limit,page);

        if (orders.size()!=0){
            info.setCode(0);
            info.setMsg("查询店主的订单列表成功");
            info.setData(orders);
            info.setCount(orders.size());
        }else {
            info.setCode(1);
            info.setMsg("查询店主的订单列表失败");
        }

        ObjectMapper mapper=new ObjectMapper();
        String json = mapper.writeValueAsString(info);
        response.setContentType("application/json;charset=utf-8");
        response.getWriter().write(json); //字符流写回
        System.out.println("GetOrderListByOwnerIDServlet:");
        System.out.println(json);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}
