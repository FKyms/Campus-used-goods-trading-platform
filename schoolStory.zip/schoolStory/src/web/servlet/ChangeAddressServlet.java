package web.servlet;

import beans.ResultInfo;
import com.fasterxml.jackson.databind.ObjectMapper;
import service.AddressService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * 修改收获地址
 */
@WebServlet("/ChangeAddressServlet")
public class ChangeAddressServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        String specificaddr = request.getParameter("specificaddr");
        String name = request.getParameter("name");
        String phone = request.getParameter("phone");

        AddressService service=new AddressService();
        ResultInfo info=new ResultInfo();
        boolean flag = service.ChangeAddress(id,specificaddr,name,phone);
        if (flag){
            info.setCode(1);
            info.setMsg("修改地址成功");
        }else {
            info.setCode(0);
            info.setMsg("修改地址失败");
        }

        //将结果集对象ResultInfo序列表为json
        ObjectMapper mapper=new ObjectMapper();
        String json = mapper.writeValueAsString(info);
        response.setContentType("application/json;charset=utf-8");
        response.getWriter().write(json); //字符流写回
        System.out.println(json);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}
