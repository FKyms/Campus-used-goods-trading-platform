package web.servlet;

import beans.Goods;
import beans.ResultInfo;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
//import net.sf.json.JSONObject;
import com.google.gson.GsonBuilder;
import service.AddressService;
import service.GoodsService;
import utils.JsonToStrUtils;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.math.BigDecimal;

/**
 * 接口19 田国庆
 * 编辑修改我的商品（根据新的信息）
 * 输入: {id：商品id，name:商品名，detail：商品详细，count：总量，price：单价}
 * method: POST
 */


@WebServlet("/ChangeGoodServlet")
public class ChangeGoodServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //工具类String
//        String JsonStr = JsonToStrUtils.getRequestJsonString(request);
//        //Gson
//        //Gson gson = new Gson();
//        Gson gson = new GsonBuilder().setLenient().create();
//        Goods newGood = new Goods();
//        newGood = gson.fromJson(JsonStr, Goods.class);
//
//        System.out.println(newGood);

        int goodsID = Integer.parseInt(request.getParameter("goodsID"));
        String goodsName = request.getParameter("goodsName");
        String goodsDetail = request.getParameter("goodsDetail");
        String goodsClass = request.getParameter("goodsClass");
        int goodsNumber = Integer.parseInt(request.getParameter("goodsNumber"));
        BigDecimal goodsPrice = new BigDecimal(request.getParameter("goodsPrice"));
        //调用service
        GoodsService service = new GoodsService();
        ResultInfo info = new ResultInfo();
        boolean flag = service.changeGoodByNewInfo( goodsID,  goodsName,  goodsDetail,  goodsClass,  goodsPrice, goodsNumber);

        if(flag){
            info.setCode(1);
            info.setMsg("编辑修改我的商品成功");
        }else {
            info.setCode(0);
            info.setMsg("编辑修改我的商品失败");
        }

        //将结果集对象ResultInfo序列表为json
        ObjectMapper mapper=new ObjectMapper();
        String json = mapper.writeValueAsString(info);
        response.setContentType("application/json;charset=utf-8");
        response.getWriter().write(json); //字符流写回
        System.out.println(json);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}
