package web.servlet;

import beans.Order;
import beans.ResultInfo;
import com.fasterxml.jackson.databind.ObjectMapper;
import service.OrderService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
//5.24更改code
/**
 * 第二次接口 2.3(3) 田国庆
 * 获取所有订单（所有用户的）
 * method: POST
 */
@WebServlet("/GetOrderListServlet")
public class GetOrderListServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        OrderService service = new OrderService();
        ResultInfo info = new ResultInfo();
        List<Order> orders = service.getOrderList();
        if(orders != null)
        {
            info.setCode(0);
            info.setMsg("获取订单列表成功");
            info.setData(orders);
        }
        else{
            info.setCode(1);
            info.setMsg("订单列表为空或获取订单列表失败");
        }

        ObjectMapper mapper=new ObjectMapper();
        String json = mapper.writeValueAsString(info);
        response.setContentType("application/json;charset=utf-8");
        response.getWriter().write(json); //字符流写回
        System.out.println(json);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}
