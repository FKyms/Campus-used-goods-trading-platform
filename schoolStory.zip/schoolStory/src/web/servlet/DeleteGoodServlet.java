package web.servlet;

import beans.ResultInfo;
import com.fasterxml.jackson.databind.ObjectMapper;
import service.AddressService;
import service.GoodsService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * 接口18 田国庆
 * 删除我的商品（根据goodsID）
 * method: POST
 */

@WebServlet("/DeleteGoodServlet")
public class DeleteGoodServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //根据goodID获取数据
        int goodID = Integer.parseInt(request.getParameter("goodID"));
        System.out.println("从request里获取的goodID是" + goodID);

        //调用service
        GoodsService goodsService = new GoodsService();
        ResultInfo info = new ResultInfo();
        boolean flag = goodsService.deleteGoodByGoodID(goodID);
        if (flag){
            info.setCode(1);
            info.setMsg("删除我的商品成功");
        }else {
            info.setCode(0);
            info.setMsg("修改我的商品失败");
        }

        //将结果集对象ResultInfo序列表为json
        ObjectMapper mapper=new ObjectMapper();
        String json = mapper.writeValueAsString(info);
        response.setContentType("application/json;charset=utf-8");
        response.getWriter().write(json); //字符流写回
        System.out.println(json);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}
