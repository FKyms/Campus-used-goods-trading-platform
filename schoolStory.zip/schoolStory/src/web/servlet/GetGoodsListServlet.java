package web.servlet;

import beans.Goods;
import beans.ResultInfo;
import com.fasterxml.jackson.databind.ObjectMapper;
import service.GoodsService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
//5.24更改code
/**
 * 第二次接口 2.3(1) 田国庆
 * 获取所有商品（所有用户的）
 * method: POST
 */
@WebServlet("/GetGoodsListServlet")
public class GetGoodsListServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //使用service
        GoodsService goodsService = new GoodsService();
        ResultInfo info = new ResultInfo();
        List<Goods> goods = goodsService.getGoodsList();

        if(goods != null){
            info.setCode(0);
            info.setMsg("获取商品列表成功");
            info.setData(goods);
        }else {
            info.setCode(1);
            info.setMsg("获取商品列表失败或者本身没有商品");
        }


        ObjectMapper mapper=new ObjectMapper();
        String json = mapper.writeValueAsString(info);
        response.setContentType("application/json;charset=utf-8");
        response.getWriter().write(json); //字符流写回
        System.out.println(json);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}
