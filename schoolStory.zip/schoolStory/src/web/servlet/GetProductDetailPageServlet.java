package web.servlet;

import beans.Goods;
import beans.Order;
import beans.ResultInfo;
import com.fasterxml.jackson.databind.ObjectMapper;
import service.GoodsService;
import service.OrderService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 *
 * 根据订单id获取详细页面
 * method: POST
 */
@WebServlet("/GetProductDetailPageServlet")
public class GetProductDetailPageServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        GoodsService service = new GoodsService();
        ResultInfo info = new ResultInfo();
//        Goods goods  = service.
//        List<Order> orders = service.getOrderList();

//        if(orders != null)
//        {
//            info.setCode(1);
//            info.setMsg("获取订单列表成功");
//            info.setData(orders);
//        }
//        else{
//            info.setCode(0);
//            info.setMsg("订单列表为空或获取订单列表失败");
//        }
//
//        ObjectMapper mapper=new ObjectMapper();
//        String json = mapper.writeValueAsString(info);
//        response.setContentType("application/json;charset=utf-8");
//        response.getWriter().write(json); //字符流写回
//        System.out.println(json);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}
