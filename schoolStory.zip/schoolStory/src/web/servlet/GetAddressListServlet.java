package web.servlet;

import beans.Address;
import beans.ResultInfo;
import beans.User;
import com.fasterxml.jackson.databind.ObjectMapper;
import service.AddressService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

/**
 * 接口14
 * 获取收货人信息列表（根据userID）
 * method: GET
 */
@WebServlet("/GetAddressListServlet")
public class GetAddressListServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //获取用户的id
        HttpSession session = request.getSession();
        User u= (User)session.getAttribute("user");
        int id = u.getUserID();
//        int id = 1;
        String  pageStr = request.getParameter("page");
        String limitStr =request.getParameter("limit");
        ResultInfo info = new ResultInfo();
        if((pageStr==""&&limitStr=="")||(pageStr==null&&limitStr==null))
        {//获取全表
            AddressService service = new AddressService();

            List<Address> addresses = service.findAddressListById(id);
            if(addresses != null)
            {
                info.setCode(1);
                info.setMsg("获取收货人信息列表成功");
                info.setData(addresses);
                info.setCount(addresses.size());
            }else{
                info.setCode(0);
                info.setMsg("收货人地址为空或获取列表失败");
            }
        }
        else
        {//获取分页式表格
            int page  = Integer.parseInt(pageStr);
            int limit = Integer.parseInt(limitStr);
            AddressService service = new AddressService();
            List<Address> addresses = service.findAddressListById(id,limit,page);
            if(addresses != null)
            {
                info.setCode(0);
                info.setMsg("获取收货人信息列表成功");
                info.setData(addresses);
                info.setCount(addresses.size());
            }else{
                info.setCode(1);
                info.setMsg("收货人地址为空或获取列表失败");
            }
        }



        /**
         * {"code":1,
         *  "msg":"获取收货人信息列表成功",
         *  "data":[{"addressID":1,"userID":12,"specificaddr":"江干区",
         *           "name":"无名氏先生","phone":"1234567890123"
         *           },
         *          {}
         *         ]
         */
        ObjectMapper mapper=new ObjectMapper();
        String json = mapper.writeValueAsString(info);
        response.setContentType("application/json;charset=utf-8");
        response.getWriter().write(json); //字符流写回
        System.out.println(json);
    }
}
