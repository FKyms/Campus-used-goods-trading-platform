package web.servlet;

import beans.Goods;
import beans.ResultInfo;
import beans.User;
import com.fasterxml.jackson.databind.ObjectMapper;
import service.CartService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

/**
 * 获取购物车列表
 */
@WebServlet("/GetCartListServlet")
public class GetCartListServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        User u= (User)session.getAttribute("user");
        int id = u.getUserID();
//        int id=1;

        CartService service=new CartService();
        ResultInfo info=new ResultInfo();
        List<Goods> goods = service.getCartListByUID(id);
        if (goods!=null){
            info.setCode(1);
            info.setMsg("获取购物车列表成功");
            info.setData(goods);
            info.setCount(goods.size());
        }else {
            info.setCode(0);
            info.setMsg("获取购物车列表失败");
        }

        /**
         * {"code":1,"data":[{"goodsID":1,"goodsName":"三体","goodsClass":null,"goodsDetail":"玄幻小说",
         * "goodsPrice":4.44,"goodsSeller":0,"goodsNumber":0,"goodsPicturePath":"a.jpg","count":1},
         * {"goodsID":2,"goodsName":"课本","goodsClass":null,"goodsDetail":"java相关","goodsPrice":15.20,
         * "goodsSeller":0,"goodsNumber":0,"goodsPicturePath":"b.jpg","count":1}],"msg":"获取购物车列表成功"}
         * 返回数据格式如上，取其中的goodsID goodsName goodsDetail goodsPrice goodsPicturePath count即可
         */
        ObjectMapper mapper=new ObjectMapper();
        String json = mapper.writeValueAsString(info);
        response.setContentType("application/json;charset=utf-8");
        response.getWriter().write(json); //字符流写回
        System.out.println(json);
    }
}
