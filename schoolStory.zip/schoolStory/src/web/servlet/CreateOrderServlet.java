package web.servlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import beans.Address;
import beans.Goods;
import beans.Order;
import beans.ResultInfo;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
//import net.sf.json.*;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import service.OrderService;
import utils.JsonToStrUtils;

/**
 * 接口15 田国庆
 * 下单生成订单列表（每种商品生成一个订单）
 * method: POST
 */
@WebServlet("/CreateOrderServlet")
public class CreateOrderServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        /**
         * 自己构建
         * userID:用户id,（根据收货地址id，所以不能为空）
         * orderDateTime:下单时间(的String)
         *
         * 输入
         * {
         * orderlist:[
         * {id:商品id，count:购买数量}，
         * …
         * ],
         * orderaddr（收货人信息）：{ id：收货地址id，specificaddr:具体住址，name:收货人名，phone: 收货人电话号码}
         */
//        request.setCharacterEncoding("utf-8");
        //工具类
        String JsonStr = JsonToStrUtils.getRequestJsonString(request);
        System.out.println(JsonStr);
        JsonParser parser = new JsonParser();
        JsonObject jsonObj = parser.parse(JsonStr).getAsJsonObject();
        System.out.println(jsonObj);

        //获取addr
        JsonObject addrObj = jsonObj.getAsJsonObject("orderaddr");
        int addrID = addrObj.get("addressID").getAsInt();
        String specificaddr = addrObj.get("specificaddr").getAsString();
        String name = addrObj.get("name").getAsString();
        String phone = addrObj.get("phone").getAsString();
        Address address = new Address();
        address.setAddressID(addrID);
        address.setSpecificaddr(specificaddr);
        address.setName(name);
        address.setPhone(phone);
        System.out.println("addr"+address);
        //购买列表
        JsonArray goodsListArray = jsonObj.getAsJsonArray("orderlist");
        List<Goods> goodsList = new ArrayList<>();
        Goods orderItemInList = null;
        int orderArraySize = goodsListArray.size();
        for(int i = 0;i < orderArraySize;i++)
        {
            orderItemInList = new Goods();
            orderItemInList.setGoodsID(goodsListArray.get(i).getAsJsonObject().get("goodsID").getAsInt());
            orderItemInList.setCount(goodsListArray.get(i).getAsJsonObject().get("count").getAsInt());
            goodsList.add(orderItemInList);
        }
        System.out.println("购买列表"+goodsList);

        //使用service
        OrderService service = new OrderService();
        ResultInfo info = new ResultInfo();
        List<Integer> list = service.CreateOrder(goodsList, address);

        if (list.size()!=0){
            info.setCode(1);
            info.setMsg("创造订单成功");
            info.setData(list);
        }else {
            info.setCode(0);
            info.setMsg("创造订单失败");
        }
        
        ObjectMapper mapper=new ObjectMapper();
        String json = mapper.writeValueAsString(info);
        response.setContentType("application/json;charset=utf-8");
        response.getWriter().write(json); //字符流写回
        System.out.println(json);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}
