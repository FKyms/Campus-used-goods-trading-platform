package web.servlet;

import beans.Goods;
import beans.Order;
import beans.OrderDetail;
import beans.ResultInfo;
import com.fasterxml.jackson.databind.ObjectMapper;
import service.OrderService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * 接口13
 * 根据订单id获取订单详细
 * method: POST
 */
@WebServlet("/GetOrderDetailServlet")
public class GetOrderDetailServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //传入参数：orderID
        int orderID = Integer.parseInt(request.getParameter("orderID"));

        OrderService service = new OrderService();
        ResultInfo info = new ResultInfo();
        OrderDetail orderDetail = service.getOrderDetailByOrderID(orderID);

        if(orderDetail==null)
        //if(specificOrder == null)
        {
            info.setCode(0);
            info.setMsg("根据订单id查询订单详情失败");
        }else{
            info.setCode(1);
            info.setMsg("根据订单id查询订单详情成功");
            info.setData(orderDetail);
        }

        //将结果集对象ResultInfo序列表为json
        ObjectMapper mapper=new ObjectMapper();
        String json = mapper.writeValueAsString(info);
        response.setContentType("application/json;charset=utf-8");
        response.getWriter().write(json); //字符流写回
        System.out.println(json);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}
