package web.servlet;

import beans.Goods;
import beans.OrderDetail;
import beans.ResultInfo;
import com.fasterxml.jackson.databind.ObjectMapper;
import service.GoodsService;
import service.OrderService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * 田国庆 管理员的搜索功能
 * 根据关键字搜索订单
 * GET
 */
@WebServlet("/GetOrderListByKWServlet")
public class GetOrderListByKWServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //传入参数：keyword
        String keyword = request.getParameter("keyword");
        OrderService service = new OrderService();
        ResultInfo info = new ResultInfo();
        List<OrderDetail> orderDetails = service.getOrderListByKeyword(keyword);

        if(orderDetails == null ||orderDetails.size() == 0)
        {
            info.setCode(1);
            info.setMsg("没有查询到相应的订单");
        }else{
            info.setCode(0);
            info.setMsg("成功查询到相应的订单");
            info.setData(orderDetails);
        }

        //将结果集对象ResultInfo序列表为json
        ObjectMapper mapper=new ObjectMapper();
        String json = mapper.writeValueAsString(info);
        response.setContentType("application/json;charset=utf-8");
        response.getWriter().write(json); //字符流写回
        System.out.println(json);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}
