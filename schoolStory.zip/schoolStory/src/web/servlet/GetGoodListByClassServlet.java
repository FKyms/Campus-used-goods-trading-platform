package web.servlet;

import beans.Goods;
import beans.ResultInfo;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import service.GoodsService;
import service.OrderService;
import utils.JsonToStrUtils;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * POST
 * 田国庆 第三波接口
 * 根据商品类型特征获取商品的列表
 */

@WebServlet("/GetGoodListByClassServlet")
public class GetGoodListByClassServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        /**
         * 输入
         * {
         * keyword:"",
         * type:[,,,],
         * order:-1,    //排序
         * maxprice
         * minprice
         */

        //工具类
        String JsonStr = JsonToStrUtils.getRequestJsonString(request);
        JsonParser parser = new JsonParser();
        JsonObject jsonObj = parser.parse(JsonStr).getAsJsonObject();
        System.out.println(jsonObj);

        String keyword = jsonObj.get("keyword").getAsString();
        int order = jsonObj.get("order").getAsInt();
        BigDecimal maxprice = jsonObj.get("maxprice").getAsBigDecimal();
        BigDecimal minprice = jsonObj.get("minprice").getAsBigDecimal();

        JsonArray type = jsonObj.getAsJsonArray("type");
        System.out.println(type);
        int typeLen = type.size();
        List<String> typeStr = new ArrayList<>();
        for(int i = 0; i < typeLen; i++){
            typeStr.add(type.get(i).getAsString());
        }

        //使用service
        GoodsService service = new GoodsService();
        ResultInfo info = new ResultInfo();
        List<Goods> goods = service.getGoodListByClass(keyword, typeStr, order, maxprice, minprice);
        System.out.println(goods);

        if (goods != null && goods.size() > 0){
            info.setCode(1);
            info.setMsg("查询指定特征的商品成功");
            info.setData(goods);
        }else {
            info.setCode(1);
            info.setMsg("无数据");
            info.setData(null);
        }

        ObjectMapper mapper=new ObjectMapper();
        String json = mapper.writeValueAsString(info);
        response.setContentType("application/json;charset=utf-8");
        response.getWriter().write(json); //字符流写回
        System.out.println(json);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}
