package web.servlet;

import beans.ResultInfo;
import beans.WebData;
import com.fasterxml.jackson.databind.ObjectMapper;
import service.GoodsService;
import service.UserService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * 第二次接口 2.1(1) 田国庆
 * 获取网站数据（此处返回注册用户数，商品库存总数）
 * method: GET
 */
@WebServlet("/GetWebDataServlet")
public class GetWebDataServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        UserService userService = new UserService();
        GoodsService goodsService = new GoodsService();
        ResultInfo info = new ResultInfo();
        int usersNum = userService.getUsersNum();
        int goodsNum = goodsService.getGoodsNum();
        WebData webData = new WebData(usersNum, goodsNum);

        if (usersNum != -1 && goodsNum != -1){
            info.setCode(1);
            info.setData(webData);
            info.setMsg("获取网站信息成功");
        }else {
            info.setCode(0);
            info.setMsg("获取网站信息失败");
        }

        ObjectMapper mapper=new ObjectMapper();
        String json = mapper.writeValueAsString(info);
        response.setContentType("application/json;charset=utf-8");
        response.getWriter().write(json); //字符流写回
    }
}
