package web.servlet;

import beans.ResultInfo;
import com.fasterxml.jackson.databind.ObjectMapper;
import service.OrderService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * POST
 * 田国庆 第三波接口
 * 签收订单
 */
@WebServlet("/SignForOrderServlet")
public class SignForOrderServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //根据orderID
        int orderID = Integer.parseInt(request.getParameter("orderID"));
        System.out.println("从request里获取的orderID是" + orderID);
        //int orderID = 15;

        OrderService service = new OrderService();
        ResultInfo info = new ResultInfo();
        boolean flag = service.signForOrder(orderID);
        if (flag){
            info.setCode(1);
            info.setMsg("签收订单成功");
        }else {
            info.setCode(0);
            info.setMsg("签收订单失败");
        }

        //将结果集对象ResultInfo序列表为json
        ObjectMapper mapper=new ObjectMapper();
        String json = mapper.writeValueAsString(info);
        response.setContentType("application/json;charset=utf-8");
        response.getWriter().write(json); //字符流写回
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}
