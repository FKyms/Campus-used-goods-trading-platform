package web.servlet;

import beans.ResultInfo;
import beans.User;
import com.fasterxml.jackson.databind.ObjectMapper;
import service.CartService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * 添加商品到购物车
 */
@WebServlet("/AddGoodsToCartsServlet")
public class AddGoodsToCartsServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        User u= (User)session.getAttribute("user");
        int userID = u.getUserID();
//        int userID = 1;
        int goodsID = Integer.parseInt(request.getParameter("goodsID"));
        int count = Integer.parseInt(request.getParameter("count"));
        System.out.println(count);
        System.out.println(goodsID);
        CartService service=new CartService();
        ResultInfo info=new ResultInfo();
        boolean flag = service.addGoodsToCarts(userID,goodsID,count);
        if (flag){
            info.setCode(1);
            info.setMsg("添加商品到购物车成功");
        }else {
            info.setCode(0);
            info.setMsg("添加商品到购物车失败");
        }


        ObjectMapper mapper=new ObjectMapper();
        String json = mapper.writeValueAsString(info);
        response.setContentType("application/json;charset=utf-8");
        response.getWriter().write(json); //字符流写回
        System.out.println(json);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}
