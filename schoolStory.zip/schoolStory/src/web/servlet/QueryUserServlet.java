package web.servlet;

import beans.ResultInfo;
import beans.User;
import com.fasterxml.jackson.databind.ObjectMapper;
import service.UserService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * 根据session里的用户信息到后台获取用户信息
 */
@WebServlet("/QueryUserServlet")
public class QueryUserServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        User user =(User) session.getAttribute("user");//session里数据格式定位 userID:ID号这种形式
        int id=user.getUserID();
        UserService service=new UserService();
        ResultInfo info=new ResultInfo();
        User userById =service.findUserById(id);
        if (userById!=null){
            info.setCode(1);
            info.setMsg("查询用户及其地址成功");
            info.setData(userById);
        }else {
            info.setCode(0);
            info.setMsg("查询用户及其地址失败");
        }

        /**
         * 返回的数据格式如下，若想修改数据格式，可以修改对应的toString方法
         * {"code":1,"data":{"userID":1,"userName":"超超","userPW":null,"userPhone":null,"userEmail":"894942308@qq",
         * "addressList":[{"addressID":1,"userID":1,"specificAddr":"cccc","name":"超超","phone":"17771603187"},
         * {"addressID":2,"userID":1,"specificAddr":"dddd","name":"22","phone":"325534"}]},"msg":"查询用户及其地址成功"}
         */
        ObjectMapper mapper=new ObjectMapper();
        String json = mapper.writeValueAsString(info);
        response.setContentType("application/json;charset=utf-8");
        //response.getOutputStream().write(json.getBytes()); 字节流写回数据
        response.getWriter().write(json); //字符流写回
        System.out.println(json);
    }
}
