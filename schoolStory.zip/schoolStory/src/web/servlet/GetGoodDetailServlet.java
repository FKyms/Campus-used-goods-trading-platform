package web.servlet;

import beans.Goods;
import beans.OrderDetail;
import beans.ResultInfo;
import com.fasterxml.jackson.databind.ObjectMapper;
import service.GoodsService;
import service.OrderService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * 田国庆
 * 第三波接口
 * 根据商品id获取商品的详细
 * method: POST
 */
@WebServlet("/GetGoodDetailServlet")
public class GetGoodDetailServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //传入参数：goodID
        int goodID = Integer.parseInt(request.getParameter("id"));
        //1 22
//        int goodID = 22;
        GoodsService service = new GoodsService();
        ResultInfo info = new ResultInfo();
        Goods detailGood = service.getGoodDetailByID(goodID);

        if(detailGood == null)
        {
            info.setCode(0);
            info.setMsg("根据商品id查询商品详情失败");
        }else{
            info.setCode(1);
            info.setMsg("根据商品id查询商品详情成功");
            info.setData(detailGood);
        }

        //将结果集对象ResultInfo序列表为json
        ObjectMapper mapper=new ObjectMapper();
        String json = mapper.writeValueAsString(info);
        response.setContentType("application/json;charset=utf-8");
        response.getWriter().write(json); //字符流写回
        System.out.println(json);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}
